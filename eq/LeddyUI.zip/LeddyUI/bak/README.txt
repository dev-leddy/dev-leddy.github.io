Neue Velious
Compliled by Thex of Selos, Formerly Oook of Agnarr
Version 1.5 - May 13, 2020
Folder Name: neue_velious

-----------------------------------------
Updated May 13, 2020

Patched to work with the latest changes on Live.

Updated April 28, 2019

1.4 - Includes Finamdar's Tabless Chat to return chat windows back to normal. Will not work with tell windows! Remember to rename your chat windows to a single blank space to get the full Velious effect.

Also fixed the hotbar to show a background for the 11 & 12 hotbar items.

Updated March 14, 2019

1.3 - Includes changes to support tabbed chat windows care of Drakah.

Updated March 9, 2019
1.2 - Updated to be compatible with current patch. Likely reverted some of the changes made in 1.1 to remove titles for a number of windows. Hope to work on fixing some contrast issues on buttons in the future.

Updated June 23, 2017
1.1 - Removed titles from a number of windows that are typically always on screen to better match the original transparent UI. Added necessary UI files for these windows instead of using the default.

Updated June 11, 2017
Initial release - this is lightly modified version of Drakah's Default "Old" Interface, which uses the window pieces and spell gems from Antioch's FD Classic UI.

Neue Velious is a throwback to the original Kunark/Velious UI and uses the original pre-Luclin spell icons and gems.
-----------------------------------------

CREDITS:
EverQuest Default "old" Interface, Updated by Drakah
FD Classic UI, Created by Antioch
Tabless Chat, by Finamdar

In Memory of Ilyana Grimm of the Fippy Darkpaw server

Special thanks to Fnyyen on EQInterface for their help in getting this working again.